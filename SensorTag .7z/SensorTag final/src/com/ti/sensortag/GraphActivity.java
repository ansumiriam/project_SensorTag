package com.ti.sensortag;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.SeriesSelection;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import DB.DBHandler;
import DB.Temperature;
import android.os.Bundle;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Paint.Align;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class GraphActivity extends Activity {
private GraphicalView mChart;
private DBHandler db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		db=new DBHandler(getApplicationContext());
		
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_graph); 
		
		// reading data from db
        Log.i("Reading", "Reading Records...");

        List<Temperature> temp = db.getAllTempReadings();

        int arraySize=temp.size();
       final double TArray[]=new double [arraySize];//temperature array
       final String TSArray[]=new String[arraySize];//timestamp array
       
     Log.d("tempSize", String.valueOf(temp.size()));

                   // Reading values into the array!

            for(int i=0;i<arraySize;i++){

                TArray[i]=Double.parseDouble(temp.get(i).getTemperature());
                Log.d("TArray", String.valueOf(TArray[i]));
                TSArray[i]=temp.get(i).getTimestamp();
               // System.out.println("i: "+ TArray[i]);
                Log.d("TSArray",TSArray[i]);
                
        }
	     int dateArraySize=TSArray.length;
	     Date dateArray[]=new Date[dateArraySize];
	    
	  
	    for (int i=0;i<TSArray.length;i++)
	    {
	
		try {
			//converting String date to Date object
			
			dateArray[i]=new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.ENGLISH).parse(TSArray[i]);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   
	    Log.d("dateArray",String.valueOf(dateArray[i]));
	    }
        
	  
	    

	    
	 	
		//------------------------------------graph code---------------------------------------------------------------
		 
	    //Creating Timeseries 
	    //timeseries takes (Date,double) or (double,double)
	    //use timechart for (Date,double) and linechart for(double,double)
	    
	    TimeSeries series=new TimeSeries("Temperature"); // a series exists for each line
	    TimeSeries hypothermia =new TimeSeries("Hypothermia"); //temperature < 35 C
	    TimeSeries fever=new TimeSeries("Fever");//temperature>37.5 C
	    TimeSeries normal=new TimeSeries("Normal");// 36.4 C
         
	    double hArray[]=new double[dateArraySize];
	    double fArray[]=new double[dateArraySize];
	    double nArray[]=new double[dateArraySize];
	    
	    //adding values to the timeseries
         for(int i=0;i<dateArray.length;i++){
             series.add(dateArray[i],TArray[i]);// adding each point to the series
             hArray[i]=35;
             fArray[i]=37.5;
             nArray[i]=36.4;
             hypothermia.add(dateArray[i], hArray[i]);
             fever.add(dateArray[i], fArray[i]);
             normal.add(dateArray[i], nArray[i]);
         }
        
          XYMultipleSeriesDataset dataset=new XYMultipleSeriesDataset();//dataset to hold series.
        
         
         //Adding each series to the dataset
         dataset.addSeries(series); //temperature series
         dataset.addSeries(hypothermia);//hypothermia series
         dataset.addSeries(normal);
         dataset.addSeries(fever);
        

          // setting the properties of temperature series 
         XYSeriesRenderer renderer =new XYSeriesRenderer();
         renderer.setColor(Color.YELLOW);
         renderer.setPointStyle(PointStyle.DIAMOND);
         renderer.setFillPoints(true);
         final NumberFormat tempValueFormat=new DecimalFormat("##.##");
         renderer.setChartValuesFormat(tempValueFormat);
         renderer.setChartValuesTextSize(35);
         
         renderer.setDisplayChartValues(true);
		 renderer.setChartValuesSpacing((float)0.5);
		 renderer.setLineWidth(11);
		 
		
		 //setting the properties of hypothermia series
		 
		 XYSeriesRenderer hRenderer=new XYSeriesRenderer();
		 hRenderer.setColor(Color.MAGENTA);
		 hRenderer.setLineWidth(6);
		 
         //setting the properties of normal series
		 
		 XYSeriesRenderer nRenderer=new XYSeriesRenderer();
		 nRenderer.setColor(Color.CYAN);
		 nRenderer.setLineWidth(6);
		 
		 
		 // setting the Properties of fever series
		 
		 XYSeriesRenderer fRenderer=new XYSeriesRenderer();
		 fRenderer.setColor(Color.RED);
		 fRenderer.setLineWidth(6);
		
        
		  XYMultipleSeriesRenderer mRenderer=new XYMultipleSeriesRenderer();// mRenderer to change properties of the graph.
        
		 
         // Adding series Renderers to multiple series Renderer
		  //multiple series renderer is used to set properties to the whole graph as a whole. it cannot set properties for each series.
		  
         mRenderer.addSeriesRenderer(renderer);
         mRenderer.addSeriesRenderer(hRenderer);
         mRenderer.addSeriesRenderer(nRenderer);
         mRenderer.addSeriesRenderer(fRenderer);
       
         //Properties of the chart
         mRenderer.setBackgroundColor(Color.BLACK);
         mRenderer.setPointSize(5);
         mRenderer.setLabelsColor(Color.GREEN);
         mRenderer.setChartTitle("TEMPERATURE LINE GRAPH");
         mRenderer.setChartTitleTextSize(30);
         mRenderer.setAxesColor(Color.WHITE);
         mRenderer.setApplyBackgroundColor(true);
         mRenderer.setAxisTitleTextSize(15);
         mRenderer.setXTitle("TIME");
         mRenderer.setYTitle("TEMPERATURE");
         mRenderer.setZoomButtonsVisible(true);
         mRenderer.setXLabelsAngle(10);
         mRenderer.setYLabelsAlign(Align.LEFT);
         mRenderer.setYLabels(15);
         mRenderer.setXLabels(10);
         mRenderer.setXLabelsAlign(Align.RIGHT);
         mRenderer.setYLabelsAngle(10);
         //mRenderer.setXAxisMin(0); //does not work on timechart,works on linechart
	     //mRenderer.setXAxisMax(30); // does not work on timechart.works on linechart.
	     mRenderer.setShowGridX(true);
	     mRenderer.setShowGridY(true);
	     mRenderer.setXLabelsAlign(Align.CENTER);
	     mRenderer.setLegendTextSize(20);
	     mRenderer.setLegendHeight(40);
	     mRenderer.setFitLegend(true);
	     mRenderer.setXLabels(0);//hiding the x axis labels
         
	   /*   // displaying clicked point on graph as a toast
	      mChart.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
				SeriesSelection seriesSelection=mChart.getCurrentSeriesAndPoint();
				if(seriesSelection !=null){
					//x values
					long clickedDateSeconds=(long)seriesSelection.getXValue();
					Date clickedDate=new Date(clickedDateSeconds);
					String strDate=sdf.format(clickedDate);
					//y values
					float amount=(float)seriesSelection.getValue();
					
					//displaying toast msg
					Toast.makeText(getBaseContext(), strDate+" Temperature: "+amount, Toast.LENGTH_SHORT).show();
							}
			}
		});*/
	      
          LinearLayout layout=(LinearLayout)findViewById(R.id.lineGraph); //the layout on the activity_graph.xml file.
          mChart = (GraphicalView)ChartFactory.getTimeChartView(getBaseContext(), dataset,mRenderer, "dd-MM-yyyy hh:mm:ss");
          layout.addView(mChart);
          if(mChart==null){
              Log.i("mChart: ", "null");
          }
          else{
              Log.i("mChart: ", "not null but not displaying graph");
          }

     
     // to delete all values from the database     
     Button delBtn=(Button)findViewById(R.id.delBtn);
     delBtn.setOnClickListener(new View.OnClickListener() {
	
	@Override
	public void onClick(View v) {
		db.deleteTempReadings();
		Toast.makeText(getBaseContext(), "Deleting data...", Toast.LENGTH_SHORT).show();
			
		}
		
	
});
          
	}
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.graph, menu);
		return true;
	}

}
