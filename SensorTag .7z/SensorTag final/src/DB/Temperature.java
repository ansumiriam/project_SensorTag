package DB;

import java.util.Date;

public class Temperature {
 String sensorId;
 String temperature;
 String timestamp;
 
 
 


public Temperature(){}
 
 public Temperature(String temperature){
	 this.temperature=temperature;
 }
 
 public Temperature(String sensorId,String temperature){
	 this.sensorId=sensorId;
	 this.temperature=temperature;
 }
 
 
 public String getSensorId() {
	return sensorId;
}
public void setSensorId(String sensorId) {
	this.sensorId = sensorId;
}
public String getTemperature() {
	return temperature;
}
public void setTemperature(String temperature) {
	this.temperature = temperature;
}
public String getTimestamp() {
	return timestamp;
}
public void setTimestamp(String timestamp) {
	this.timestamp = timestamp;
}




}
