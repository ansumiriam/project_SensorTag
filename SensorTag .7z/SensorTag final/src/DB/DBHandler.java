package DB;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import DB.DBHandler;
import DB.Temperature;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHandler  extends SQLiteOpenHelper{
	private static final String DATABASE_NAME = "SensorDB";
    private static final int DATABASE_VERSION = 1;
    private static final String LOG = DBHandler.class.getName();

    // TABLE NAMES
    private static final String TEMPERATURE_TABLE = "temp_table";

    // temperature class
    
    private static final String KEY_SENSOR_ID = "sensor_id";
    private static final String KEY_TEMPERATURE = "temperature";
    private static final String KEY_TIMESTAMP = "timestamp";

    String CREATE_TEMP_TABLE = "CREATE TABLE " + TEMPERATURE_TABLE + "("
    		//+ KEY_PATIENT_ID + "TEXT ,"
            + KEY_SENSOR_ID + " TEXT ,"
    		+ KEY_TEMPERATURE + " TEXT, "
            + KEY_TIMESTAMP + " TEXT  DEFAULT CURRENT_TIMESTAMP)";

    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TEMP_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TEMPERATURE_TABLE);
        onCreate(db);
    }

    // CRUD OPERATIONS
    // --TEMPERATURETABLE--//

    // INSERT RECORD INTO TEMPERATURE TABLE
    public void insertTemperature(Temperature temp) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "dd-MM-yyyy hh:mm:ss", Locale.getDefault());
        Date date = new Date();
       // values.put(KEY_PATIENT_ID, temp.getPatientId());
        values.put(KEY_SENSOR_ID, temp.getSensorId());
        values.put(KEY_TEMPERATURE, temp.getTemperature());
        values.put(KEY_TIMESTAMP, dateFormat.format(date));

        try
        {
            db.insert(TEMPERATURE_TABLE, null, values);         
        }catch(Exception ex){
            Log.d("Exception in inserting data", ex.toString());
        }finally{
            db.close(); 
        }
    }

    // READ ALL RECORDS
    public List<Temperature> getAllTempReadings() {
        List<Temperature> temp = new ArrayList<Temperature>();
        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT * FROM " + TEMPERATURE_TABLE;

        Cursor c = db.rawQuery(selectQuery, null);
        if (c.moveToFirst()) {
            do {
                Temperature t = new Temperature(); 
                t.setSensorId(c.getString(0));
                t.setTemperature(c.getString(1));
                Calendar cal=new GregorianCalendar();
 	             SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy hh:mm:ss",Locale.getDefault());
 	             java.util.Date dt = null;
				 t.setTimestamp(c.getString(2));
                temp.add(t);                
            } while (c.moveToNext());
        }

        return temp;
    }
    

    // DELETE All RECORDs
    public void deleteTempReadings() {
        SQLiteDatabase db = this.getWritableDatabase();
        String selectQuery = "Delete from " + TEMPERATURE_TABLE;
        db.execSQL(selectQuery);
        Log.d(LOG, selectQuery);
    }
    
   
    }

